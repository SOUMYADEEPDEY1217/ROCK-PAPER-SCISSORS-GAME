let userScore = 0;
let opponentScore = 0;
let isPVP = false;
const clickSound = document.getElementById('clickSound');
const resultEl = document.getElementById('result');
const scoreEl = document.getElementById('score');
const pvpInputs = document.getElementById('pvp-inputs');
const buttons = document.getElementById('buttons');

function play(userChoice) {
  if (isPVP) return;
  clickSound.play();
  const choices = ['rock', 'paper', 'scissors'];
  const computerChoice = choices[Math.floor(Math.random() * 3)];
  let result = '';
  if (userChoice === computerChoice) {
    result = "It's a draw!";
  } else if (
    (userChoice === 'rock' && computerChoice === 'scissors') ||
    (userChoice === 'paper' && computerChoice === 'rock') ||
    (userChoice === 'scissors' && computerChoice === 'paper')
  ) {
    result = `You win! ${userChoice} beats ${computerChoice}`;
    userScore++;
  } else {
    result = `You lose! ${computerChoice} beats ${userChoice}`;
    opponentScore++;
  }
  showResult(result);
}

function playPVP() {
  const p1 = document.getElementById('p1-choice').value;
  const p2 = document.getElementById('p2-choice').value;
  clickSound.play();
  let result = '';
  if (p1 === p2) {
    result = "It's a draw!";
  } else if (
    (p1 === 'rock' && p2 === 'scissors') ||
    (p1 === 'paper' && p2 === 'rock') ||
    (p1 === 'scissors' && p2 === 'paper')
  ) {
    result = `Player 1 wins! ${p1} beats ${p2}`;
    userScore++;
  } else {
    result = `Player 2 wins! ${p2} beats ${p1}`;
    opponentScore++;
  }
  showResult(result);
}

function showResult(text) {
  resultEl.textContent = text;
  resultEl.classList.remove('animate');
  void resultEl.offsetWidth;
  resultEl.classList.add('animate');
  scoreEl.textContent = `You: ${userScore} | Opponent: ${opponentScore}`;
}

document.getElementById('resetBtn').addEventListener('click', () => {
  userScore = 0;
  opponentScore = 0;
  showResult("Scores reset!");
});

document.getElementById('darkModeToggle').addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
});

document.getElementById('toggleModeBtn').addEventListener('click', () => {
  isPVP = !isPVP;
  if (isPVP) {
    buttons.style.display = "none";
    pvpInputs.style.display = "block";
    document.getElementById('toggleModeBtn').textContent = "🔁 Switch to Player vs Computer";
  } else {
    buttons.style.display = "block";
    pvpInputs.style.display = "none";
    document.getElementById('toggleModeBtn').textContent = "🔁 Switch to Player vs Player";
  }
});